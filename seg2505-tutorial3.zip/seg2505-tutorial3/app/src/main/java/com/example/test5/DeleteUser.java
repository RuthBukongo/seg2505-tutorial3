package com.example.test5;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.test5.R;
import com.example.test5.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DeleteUser extends AppCompatActivity {
    static FirebaseDatabase DB = FirebaseDatabase.getInstance();
    private static String TAG = "Reader";
    static DatabaseReference reference = DB.getReference("Path1");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_reader);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void lookFor(View v) {
        String emailKey = (String) ((EditText) findViewById(R.id.emailInput)).getText().toString();

        reference.child(emailKey).removeValue().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                System.out.println("User deleted successfully.");
            } else {
                System.err.println("Failed to delete user: " + task.getException());
            }
        });
    }
}

/*
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e("FirebaseData", "Error fetching user data", databaseError.toException());
            }
        });
        /*Log.d(TAG, "txt1: "+txt1);
        reference.child(txt1).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    Log.d("firebase", String.valueOf(task.getResult().getValue()));
                }
                Log.d(TAG, String.valueOf(task.getResult().getValue().getClass()));
            }
        });*/

