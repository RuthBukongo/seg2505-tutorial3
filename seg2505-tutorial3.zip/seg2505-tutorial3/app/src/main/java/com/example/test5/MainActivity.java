package com.example.test5;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.test5.ui.Reader;
import com.example.test5.ui.UploadFromJSON;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.test5.databinding.ActivityMainBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private static String TAG = "MainActivityTag";
    private ActivityMainBinding binding;
    FirebaseDatabase DB;
    DatabaseReference reference;
    private BroadcastReceiver myReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            erase();
        }
    };
    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter("com.example.CUSTOM_EVENT");
        registerReceiver(myReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(myReceiver);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        //NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        //NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        //NavigationUI.setupWithNavController(binding.navView, navController);
    }
    public void onPress(View v){
        // = FirebaseDatabase.getInstance();
        // myRef = database.getReference("message");
        DB = FirebaseDatabase.getInstance();
        reference = DB.getReference("Path1");
        String username = (String)((EditText)findViewById(R.id.username)).getText().toString();
        String email = (String)((EditText)findViewById(R.id.email)).getText().toString();

        User usr = new User(this, username,email);

        //myRef.setValue("Hello, World!");
        //myRef.addValueEventListener(new ValueEventListener() {
        /*
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue(String.class);
                Log.d(TAG, "Value is: " + value);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });*/
    }
    private void erase(){
        ((TextView)findViewById(R.id.email)).setText("");
        ((TextView)findViewById(R.id.username)).setText("");
    }
    public void launchReader(View v){
        Log.d(TAG, "launchReader: here");
        Intent i = new Intent(this , Reader.class);
        startActivity(i);
    }
    public void deleteLauncher(View v){
        Log.d(TAG, "deleteLauncher");
        Intent i = new Intent(this , DeleteUser.class);
        startActivity(i);
    }
    public void launchJsonUploader(View v){
        Log.d(TAG, "JsonLauncher");
        Intent i = new Intent(this, UploadFromJSON.class);
        startActivity(i);
    }

}