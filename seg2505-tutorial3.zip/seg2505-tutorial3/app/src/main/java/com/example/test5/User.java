package com.example.test5;

import android.content.Context;
import android.content.Intent;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.IgnoreExtraProperties;



public class User {
    private Context context;
    public String username;
    public String email;

    static FirebaseDatabase DB= FirebaseDatabase.getInstance();
    static DatabaseReference reference = DB.getReference("Path1");
    public User() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public User(Context context, String username, String email) {
    this.context = context;
        this.username = username;
        this.email = email;
        reference.child(email).setValue(this).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                Intent intent = new Intent("com.example.CUSTOM_EVENT");
                context.sendBroadcast(intent);
            }
        });
    }

    public String getEmail() {
        return email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}