package com.example.test5.ui;

import android.content.Context;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.example.test5.User;
import com.google.firebase.crashlytics.buildtools.reloc.com.google.common.reflect.TypeToken;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;
//import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;

public class UploadFromJSON extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Step 1: Read the file from device storage
        String jsonData = readFileFromExternalStorage(this, "users.json");
        List<User> users = parseJsonToUserList(jsonData);
        uploadUsersToFirebase(users);

        finish();
    }

    public String readFileFromExternalStorage(Context context, String fileName) {
        File file = new File(context.getExternalFilesDir(null), fileName);
        StringBuilder stringBuilder = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }

    public List<User> parseJsonToUserList(String jsonData) {
        Gson gson = new Gson();
        Type userListType = new TypeToken<List<User>>() {}.getType();
        return gson.fromJson(jsonData, userListType);
    }

    public void uploadUsersToFirebase(List<User> users) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Path1");

        for (User user : users) {
            reference.child(user.getEmail().replace(".", ",")).setValue(user)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            System.out.println("User uploaded successfully: " + user.getUsername());
                        } else {
                            System.err.println("Error uploading user: " + user.getUsername());
                        }
                    });
        }
    }
}
